const processText = async (text) => {
  const lines = TextDecoderStream.Blocks.filter(block => {
    return block.BlockType === "Line"
  })
  return lines.join(line => {
    return line.Text
  })
};

module.exports = { processText };